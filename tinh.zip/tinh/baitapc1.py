print("Hello word Toi ten la Tinh")
